Bruce_Dreckman <- read.csv("~/Desktop/Analyzing Baseball Data with R/2018 Giants Umpires/Bruce_Dreckman_4:4:18.csv")
